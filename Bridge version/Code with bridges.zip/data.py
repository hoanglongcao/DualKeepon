# -*- coding: iso-8859-1 -*-
from PIL import Image, ImageTk
from openpyxl import load_workbook

excelFile = load_workbook(filename='Datas.xlsx')

sheetQuiz = excelFile['Quiz']
sheetGeneral = excelFile['General']

########################### DISPLAYED TEXTS #############################

def textOutQuiz():
    """Dictionary of all the texts which will be in the beginning and the end of the quiz"""
    dictionaryTexts = {}
    dictionaryTexts["welcomeText"] = sheetGeneral['B2'].value
    dictionaryTexts["PictureRight"] = sheetGeneral['B3'].value
    dictionaryTexts["PictureLeft"] = sheetGeneral['B4'].value
    dictionaryTexts["Introduction"] = sheetGeneral['B7'].value
    dictionaryTexts["Forms"] = sheetGeneral['B8'].value
    dictionaryTexts["Name"] = sheetGeneral['B9'].value
    dictionaryTexts["firstName"] = sheetGeneral['B10'].value
    dictionaryTexts["Age"] = sheetGeneral['B11'].value
    dictionaryTexts["Gender"] = sheetGeneral['B12'].value
    dictionaryTexts["male"] = sheetGeneral['B13'].value
    dictionaryTexts["female"] = sheetGeneral['B14'].value
    #dictionaryTexts["Rules"] = sheetGeneral.cell(row = 17,column = 2).value
    dictionaryTexts["Rules"] = sheetGeneral['B17'].value
    dictionaryTexts["PictureRules"] = sheetGeneral['B18'].value
    dictionaryTexts["End"] = sheetGeneral['B21'].value
    dictionaryTexts["PictureEnd"] = sheetGeneral['B22'].value
    dictionaryTexts["buttonNext"] = sheetGeneral['B25'].value
    dictionaryTexts["buttonQuit"] = sheetGeneral['B26'].value
    dictionaryTexts["alert"] = sheetGeneral['B29'].value
    return dictionaryTexts

##def test_textOutQuiz():
##    text = textOutQuiz()
##    for i in text:
##        print(i + ': ' + text[i])
##
##test_textOutQuiz()

def textQuiz():
    """Dictionary of all the texts which will be in the quiz"""
    dictionaryTexts = {}
    i = 0
    stop = 0
    while stop == 0:
        ################################ PYTHON 2.7 START #######################
        a = sheetQuiz.cell(row = i+4,column = 2).value
        ################################ PYTHON 2.7 END #######################
        dictionaryTexts[i] = a
        ################################ PYTHON 2.7 START #######################
        if type(dictionaryTexts[i]) != unicode:
        ################################ PYTHON 2.7 END #######################
            del dictionaryTexts[i]
            stop = 1
        i = i+1
    return dictionaryTexts

##def test_textQuiz():
##    text = textQuiz()
##    for i in text:
##        print(str(i) + ': ' + text[i])
##
##test_textQuiz()

########################### PICTURES #############################
def resizePicture(a,size):
    """Resize the picture for the window"""
    img = Image.open(a)
    x, y = img.size
    if x > y:
        x_new = size
        factorX = size/x
        y_new = int(y*factorX)
    elif x == y:
        x_new = size
        y_new = size
    else:
        y_new = size
        factorY = size/y
        x_new = int(x*factorY)
    newImage = img.resize((x_new,y_new),Image.ANTIALIAS)
    newImage.save(a)
    return a

def pictures(folderName,numberColumn):
    """Dictionnary of all pictures for the quiz
    (male for right and female for left)
    Parameters: folderName for the name of the folder (in a string)
    and numberColumn for the gender (3 for left and 4 for right)
    Example: {0: 'ImagesMan/1.cityMan.JPG', 1: 'ImagesMan/3.dishMan.gif',,...}
    """
    dictionaryPictures = {}
    i = 0
    stop = 0
    while stop == 0:
        a = str(sheetQuiz.cell(row = i+4,column = numberColumn).value)
        a = folderName + '/' + a
        if a == folderName + '/' + 'None':
            stop = 1
        else:
            b = resizePicture(a,500)
            dictionaryPictures[i] = b
            i = i+1
    return dictionaryPictures

##def test_pictures():
##    male = pictures('ImagesMan',4)
##    female = pictures('ImagesWoman',3)
##    for i in male:
##        print(str(i) + ': ' + male[i])
##    for j in female:
##        print(str(j) + ': ' + female[j])
##
##test_pictures()

########################### MOVE MA2 (NEW) #############################
def numberIterationEndWindow(i,finish,move,sheet,endQuestion,numberEnd,rowInit):
    """ Called in numberIteration(move,endQuestion) for the end window"""
    if move == True:
        w = sheet.cell(row = i+rowInit,column = 2).value
        x = sheet.cell(row = i+rowInit,column = 3).value
        y = sheet.cell(row = i+rowInit,column = 4).value
        z = sheet.cell(row = i+rowInit,column = 5).value
        if str(w) == str(x) == 'None' and endQuestion == False:
            finish = True
        elif str(y) == str(z) == 'None' and endQuestion == True:
            finish = True
        else:
            numberEnd = numberEnd +1
    else:
        w = sheet.cell(row = i+rowInit,column = 2).value
        if str(w) == 'None':
            finish = True
        else:
            numberEnd = numberEnd +1
    return finish, numberEnd
    
def numberIteration(move,endQuestion,sheet,rowInit):
    """ Return the number of lines of each window for movements and voices:
    (numberWelcome,numberQuiz,numberEnd,numberQuestionTotal)
    Arguments:
    - move = True if it concerned the sheet for the movement and  = False if it is for the voice
    - endQuestion = True if it concerned the end of the questions and = False if not
    NB: numberQuiz is a list with the number of lines of each question"""
    numberWelcome = 0
    numberQuiz = []
    numberEnd = 0
    finish = False
    i = 0
    numberQuestion = 0
    numberQuestionTotal = 0
    while finish == False:
        a = sheet.cell(row = i+rowInit,column = 1).value
        if a == 'Welcome window':
            currentWindow = 'welcome'
        elif type(a) == long:
            currentWindow = 'quiz'
            question = a
        elif a == 'End window':
            numberQuestionTotal = numberQuestionTotal + numberQuestion
            numberQuiz.append(numberQuestion)
            # Why adding the commands numberQuestionTotal = numberQuestionTotal + numberQuestion and numberQuiz.append(numberQuestion) here?
            # Without this, when the function will reach the line with the name 'End window',
            # currentWindow == 'end', so the function will not enter in the condition elif currentWindow == 'quiz':
            # and will not be able to add the last numberQuestion to the list numberQuiz.
            # here is a way to fix the problem
            currentWindow = 'end'
        if currentWindow == 'welcome':
            numberWelcome = numberWelcome + 1
        elif currentWindow == 'quiz':
            if str(a) == 'None' or a == 1:
                # condition a == 1 to take into account the first question. Else, it will
                # go directly to the else just below as str(a) != 'None' (a == 1 for the first time!)
                numberQuestion = numberQuestion + 1
            else:
                numberQuestionTotal = numberQuestionTotal + numberQuestion
                numberQuiz.append(numberQuestion)
                numberQuestion = 1
        else:
            finish, numberEnd = numberIterationEndWindow(i,finish,move,sheet,endQuestion,numberEnd,rowInit)
        i = i + 1
    return numberWelcome, numberQuiz, numberEnd, numberQuestionTotal

def rowInitialNumber(sheet):
    """To know what is the number of the initial row for the instructions
    Argument sheet is for the sheet of the Excel File: sheet = excelFile[sheetName]
    (see robotData(window,numberColumn,endQuestion,move,sheetName))
    """
    i = 1
    a = ''
    while a != "Question Number":
        a = sheet.cell(row = i,column = 1).value
        i = i +1
    return i

def constructionList(i,numberColumn,move,sheet,rowInit):
    """Construction of the list for the MOVEMENTS (move = True) or VOICES (move = False) of the Keepon.
    Used in the function keepon(window,numberColumn,endQuestion,move)
    rowInit is to say where the loop should begin (line number of "Welcome window")
    """
    if move == False:
        a = sheet.cell(row = i+rowInit,column = numberColumn).value
        return a
    else:
        a = sheet.cell(row = i+rowInit,column = numberColumn).value
        ################################ PYTHON 2.7 START #######################
        if type(a) == unicode:
            command = a.encode('utf-8')
        elif type(a) == float or type(a) == long:
        ################################ PYTHON 2.7 END #######################
            command = a
        else:
            command = "None"
        return command

def robotData(window,numberColumn,endQuestion,move,sheetName):
    """
    Parameters:
    If window == "welcome" and numberColumn = 3: list for the male Keepon (right) for welcome
    If window == "welcome" and numberColumn = 2: list for the female Keepon (left) for welcome
    If window == "end" and numberColumn = 3: list for the male Keepon (right) for end
    If window == "end" and numberColumn = 2: list for the female Keepon (left) for end
    If window == "quiz" and numberColumn = 3: list of lists for the male Keepon (right) for quiz
    If window == "quiz" and numberColumn = 2: list of lists for the female Keepon (left) for quiz
    If window == "quiz" and numberColumn = 5: list of lists of movements of the male Keepon (right) for end question
    If window == "quiz" and numberColumn = 4: list of lists of movements of the female Keepon (left) for end question

    If move == True, it concerns the MOVEMENTS of the robot, else it concerns the VOICES.
    This argument is used in numberIteration() and constructionList().

    endQuestion = True if it concerned the END OF THE QUESTIONS and endQuestion = False if not
    This argument is used in numberIteration().

    sheet: str --> put the NAME OF THE SHEET in the Excel File 
    """
    sheet = excelFile[sheetName]
    rowInit = rowInitialNumber(sheet)
    numberWelcome, numberQuiz, numberEnd, numberQuestionTotal = numberIteration(move,endQuestion,sheet,rowInit)
    listInstruction = []
    listInstructionQuestion = []
    if window == "welcome":
        for i in range(numberWelcome):
            instruction = constructionList(i,numberColumn,move,sheet,rowInit)
            if instruction != "None":
                listInstruction.append(instruction)
    elif window == "end":
        for i in range(numberEnd):
            n_end = i + numberWelcome + numberQuestionTotal
            instruction = constructionList(n_end,numberColumn,move,sheet,rowInit)
            if instruction != "None":
                listInstruction.append(instruction)
    elif window == "quiz":
        n_quiz = numberWelcome
        for i in numberQuiz:
            for j in range(i):
                instruction = constructionList(n_quiz,numberColumn,move,sheet,rowInit)
                if instruction != "None":
                    listInstructionQuestion.append(instruction)
                n_quiz = n_quiz + 1
            listInstruction.append(listInstructionQuestion)
            listInstructionQuestion = []
    return listInstruction

#to test that, don't forget to put the global variable test = 'Essai'

welcomeFemale = [1L,'z', 3L,'r']
welcomeMale = ['a',2L, 'e',4L]
quizFemale = [[5L,'t','s'],[8L,'f'],['w',9L,'m']]
quizMale = [[6L,'q',7L,'d'],[],['x','h']]
endFemale = [10L,11L]
endMale = []
endQuestionFemale = [[],[],[]]
endQuestionMale = [[],[],[]]

##print(robotData("welcome",3,False,True,"Essai") == welcomeMale)# ok
##print(robotData("welcome",2,False,True,"Essai") == welcomeFemale)# ok
##print(robotData("end",3,False,True,"Essai") == endMale)# ok
##print(robotData("end",2,False,True,"Essai") == endFemale)# ok
##print(robotData("quiz",3,False,True,"Essai") == quizMale)# ok
##print(robotData("quiz",2,False,True,"Essai") == quizFemale)# ok
##print(robotData("quiz",4,True,True,"Essai") == endQuestionFemale)# ok
##print(robotData("quiz",5,True,True,"Essai") == endQuestionMale)# ok
##
##print(robotData('welcome',2,False,False,"Voices"))# ok
##print(robotData('quiz',2,False,False,"Voices"))# ok
##print(robotData('quiz',3,False,False,"Voices"))# ok
##print(robotData('quiz',4,False,False,"Voices"))# ok
##print(robotData('end',2,False,False,"Voices"))# ok

########################### MOVE and VOICE MA2 (NEW) OUTDATED  AGAIN #############################
########################### MOVE and VOICE were fusioned #############################

##def constructionListMovement(i,numberColumn):
##    """Construction of the list for the movements of the Keepon.
##    Used in the function keeponMovement(window,numberColumn)
##    """
##    a = sheetKeepon.cell(row = i+rowInitialMove,column = numberColumn).value
##    ################################ PYTHON 2.7 START #######################
##    if type(a) == unicode:
##        command = a.encode('utf-8')
##    elif type(a) == float or type(a) == long:
##    ################################ PYTHON 2.7 END #######################
##        command = a
##    else:
##        command = "None"
##    return command
##
##def keeponMovement(window,numberColumn,endQuestion):
##    """
##    Parameters:
##    If window == "welcome" and numberColumn = 3: list of movements of the male Keepon (right) for welcome
##    If window == "welcome" and numberColumn = 2: list of movements of the female Keepon (left) for welcome
##    If window == "end" and numberColumn = 3: list of movements of the male Keepon (right) for end
##    If window == "end" and numberColumn = 2: list of movements of the female Keepon (left) for end
##    If window == "quiz" and numberColumn = 3: list of lists of movements of the male Keepon (right) for quiz
##    If window == "quiz" and numberColumn = 2: list of lists of movements of the female Keepon (left) for quiz
##    If window == "quiz" and numberColumn = 5: list of lists of movements of the male Keepon (right) for end question
##    If window == "quiz" and numberColumn = 4: list of lists of movements of the female Keepon (left) for end question
##    """
##    numberWelcome, numberQuiz, numberEnd, numberQuestionTotal = numberIteration(True,endQuestion)
##    listMove = []
##    listMoveQuestion = []
##    if window == "welcome":
##        for i in range(numberWelcome):
##            keeponMove = constructionListMovement(i,numberColumn)
##            if keeponMove != "None":
##                listMove.append(keeponMove)
##    elif window == "end":
##        for i in range(numberEnd):
##            n_end = i + numberWelcome + numberQuestionTotal
##            keeponMove = constructionListMovement(n_end,numberColumn)
##            if keeponMove != "None":
##                listMove.append(keeponMove)
##    elif window == "quiz":
##        n_quiz = numberWelcome
##        for i in numberQuiz:
##            for j in range(i):
##                keeponMove = constructionListMovement(n_quiz,numberColumn)
##                if keeponMove != "None":
##                    listMoveQuestion.append(keeponMove)
##                n_quiz = n_quiz + 1
##            listMove.append(listMoveQuestion)
##            listMoveQuestion = []
##    return listMove
##
##def keeponVoice(window,numberColumn):
##    """
##    Parameters:
##    If window == "welcome" and numberColumn = 2: list of voices of the Keepon's for welcome
##    If window == "end" and numberColumn = 2: list of voices of the Keepon's for end
##    If window == "quiz" and numberColumn = 2: list of lists of voices of the Keepon's for quiz
##    If window == "quiz" and numberColumn = 3: list of lists of voices of the female Keepon (left) for end question
##    If window == "quiz" and numberColumn = 4: list of lists of voices of the male Keepon (right) for end question
##    """
##    numberWelcome, numberQuiz, numberEnd, numberQuestionTotal = numberIteration(False,False)
##    listVoice = []
##    listVoiceQuestion = []
##    if window == "welcome":
##        for i in range(numberWelcome):
##            keeponVoice = sheetVoice.cell(row = i+rowInitialVoice,column = numberColumn).value
##            if keeponVoice != "None":
##                listVoice.append(keeponVoice)
##    elif window == "end":
##        for i in range(numberEnd):
##            n_end = i + numberWelcome + numberQuestionTotal
##            keeponVoice = sheetVoice.cell(row = n_end+rowInitialVoice,column = numberColumn).value
##            if keeponVoice != "None":
##                listVoice.append(keeponVoice)
##    elif window == "quiz":
##        n_quiz = numberWelcome
##        for i in numberQuiz:
##            for j in range(i):
##                keeponVoice = sheetVoice.cell(row = n_quiz+rowInitialVoice,column = numberColumn).value
##                if keeponVoice != "None":
##                    listVoiceQuestion.append(keeponVoice)
##                n_quiz = n_quiz + 1
##            listVoice.append(listVoiceQuestion)
##            listVoiceQuestion = []
##    return listVoice

##print(keeponMovement("welcome",3,False) == welcomeMale)# ok
##print(keeponMovement("welcome",2,False) == welcomeFemale)# ok
##print(keeponMovement("end",3,False) == endMale)# ok
##print(keeponMovement("end",2,False) == endFemale)# ok
##print(keeponMovement("quiz",3,False) == quizMale)# ok
##print(keeponMovement("quiz",2,False) == quizFemale)# ok
##print(keeponMovement("quiz",4,True) == endQuestionFemale)# ok
##print(keeponMovement("quiz",5,True) == endQuestionMale)# ok

##print(keeponVoice('welcome',2))# ok
##print(keeponVoice('quiz',2))# ok
##print(keeponVoice('quiz',3))# ok
##print(keeponVoice('quiz',4))# ok
##print(keeponVoice('end',2))# ok

##print(keeponMovementBis("welcome",3) == welcomeMale) # male right welcome # ok
##print(keeponMovementBis("welcome",2) == welcomeFemale)# female left welcome # ok
##print(keeponMovementBis("end",3) == endMale)# male right end # ok
##print(keeponMovementBis("end",2) == endFemale)# female right end # ok
##print(keeponMovementBis("quiz",3) == quizMale)# male right quiz # ok
##print(keeponMovementBis("quiz",2) == quizFemale)# female right quiz # ok

########################### MOVE MA2 (NEW) OUTDATED #############################

##def listColumn1(sort):
##    """It returns the list of the column 1 from the Excel file for the movements or voices of the Keepon
##    ['Welcome window', 'Welcome window',...]
##    """
##    column1 = []
##    i = 0
##    ################################ PYTHON 2.7 START #######################
##    a = u'' # to have a as unicode and not str
##    while type(a) == unicode or type(a) == long:
##    ################################ PYTHON 2.7 END #######################
##        if sort == "move":
##            a = sheetKeeponBis.cell(row = i+rowInitialMove,column = 1).value
##        elif sort == "voice":
##            a = sheetVoice.cell(row = i+rowInitialMove,column = 1).value
##        column1.append(a)
##        i = i+1
##    del(column1[-1])
##    return column1
##
##def numberIterations(window,sort):
##    """It returns the number of occurences of window (= "Welcome window" or "End window")
##    in the list created with listColumn1()
##    """
##    column1 = listColumn1(sort)
##    if window == "Welcome window" or window == "End window":
##        a = column1.count(window)
##    return a
##
##def numberIterationsQuiz(sort):
##    """It returns the number of occurences of the number for the quiz
##    in the list created with listColumn1()
##    """
##    column1 = listColumn1(sort)
##    i = 0
##    for cell in column1:
##        ################################ PYTHON 2.7 START #######################
##        if type(cell) == long:
##        ################################ PYTHON 2.7 END #######################
##            i = i +1
##    return i

##def constructionListMovementBis(i,numberColumn):
##    """Construction of the list for the movements of the Keepon.
##    Used in the function keeponMovement(window,numberColumn)
##    """
##    a = sheetKeeponBis.cell(row = i+rowInitialMove,column = numberColumn).value
##    ################################ PYTHON 2.7 START #######################
##    if type(a) == unicode:
##        command = a.encode('utf-8')
##    elif type(a) == float or type(a) == long:
##    ################################ PYTHON 2.7 END #######################
##        command = a
##    else:
##        command = "None"
##    return command

##def keeponMovement(window,numberColumn):
##    """
##    Parameters:
##    If window == "welcome" and numberColumn = 3: list of movements of the male Keepon (right) for welcome
##    If window == "welcome" and numberColumn = 2: list of movements of the female Keepon (left) for welcome
##    If window == "end" and numberColumn = 3: list of movements of the male Keepon (right) for end
##    If window == "end" and numberColumn = 2: list of movements of the female Keepon (left) for end
##    If window == "quiz" and numberColumn = 3: list of lists of movements of the male Keepon (right) for quiz
##    If window == "quiz" and numberColumn = 2: list of lists of movements of the female Keepon (left) for quiz
##    If window == "quiz" and numberColumn = 5: list of lists of movements of the male Keepon (right) for end question
##    If window == "quiz" and numberColumn = 4: list of lists of movements of the female Keepon (left) for end question
##    """
##    numberWelcome = numberIterations("Welcome window","move")
##    numberEnd = numberIterations("End window","move")
##    numberQuiz = numberIterationsQuiz("move")
##    listMove = []
##    listMoveQuestion = []
##    firstIf = False
##    if window == "welcome":
##        for i in range(numberWelcome):
##            keeponMove = constructionListMovement(i,numberColumn)
##            if keeponMove != "None":
##                listMove.append(keeponMove)
##    elif window == "end":
##        for i in range(numberEnd):
##            n = i + numberWelcome + numberQuiz
##            keeponMove = constructionListMovement(n,numberColumn)
##            if keeponMove != "None":
##                listMove.append(keeponMove)
##    elif window == "quiz":
##        for i in range(numberQuiz):
##            n = i + numberWelcome
##            keeponMove = constructionListMovement(n,numberColumn)
##            previousNumberQuestion = sheetKeepon.cell(row = n+rowInitialMove-1,column = 1).value
##            numberQuestion = sheetKeepon.cell(row = n+rowInitialMove,column = 1).value
##            if (keeponMove != "None" and numberQuestion == previousNumberQuestion) or (i == 0 and keeponMove != "None"):
##                #the second condition is to avoid taking the first element of the next question
##                #the third condition is to take the first element of the first question if keeponMove != "None"
##                    #(without it, the function will not enter the first time in the condition because
##                    #it will compare '1' to 'Welcome window' which will give false for the second condition)
##                listMoveQuestion.append(keeponMove)
##                firstIf = True
##            ################################ PYTHON 2.7 START #######################
##            if (numberQuestion != previousNumberQuestion and type(previousNumberQuestion) != unicode) or i+1 == numberQuiz:
##            ################################ PYTHON 2.7 END #######################
##                #the second condition is to include the first element of the first question in the first list of the global list
##                #the third condition is to take the last list which corresponds to the last question
##                    #(without it, the function will not enter in the condition for the last time because
##                    #it will compare '11' to '11' which will give false for the first condition)
##                listMove.append(listMoveQuestion)
##                listMoveQuestion = [keeponMove]
##                if keeponMove == 'None':
##                    listMoveQuestion = []
##                if i+1 == numberQuiz and firstIf == False:
##                    listMove.append(listMoveQuestion)
##                firstIf = False
##    return listMove

########################### VOICE KEEPON MA2 (NEW) OUTDATED#############################
##def keeponVoice(window,numberColumn):
##    """
##    Parameters:
##    If window == "welcome" and numberColumn = 2: list of voices of the Keepon's for welcome
##    If window == "end" and numberColumn = 2: list of voices of the Keepon's for end
##    If window == "quiz" and numberColumn = 2: list of lists of voices of the Keepon's for quiz
##    If window == "quiz" and numberColumn = 3: list of lists of voices of the female Keepon (left) for end question
##    If window == "quiz" and numberColumn = 4: list of lists of voices of the male Keepon (right) for end question
##    """
##    numberWelcome = numberIterations("Welcome window","voice")
##    numberEnd = numberIterations("End window","voice")
##    numberQuiz = numberIterationsQuiz("voice")
##    firstIf = False
##    listVoice = []
##    listVoiceQuestion = []
##    if window == "welcome":
##        for i in range(numberWelcome):
##            keeponVoice = sheetVoice.cell(row = i+rowInitialVoice,column = numberColumn).value
##            if keeponVoice != "None":
##                listVoice.append(keeponVoice)
##    elif window == "end":
##        for i in range(numberEnd):
##            n = i + numberWelcome + numberQuiz
##            keeponVoice = sheetVoice.cell(row = n+rowInitialVoice,column = numberColumn).value
##            if keeponVoice != "None":
##                listVoice.append(keeponVoice)
##    elif window == "quiz":
##        for i in range(numberQuiz):
##            n = i + numberWelcome
##            keeponVoice = sheetVoice.cell(row = n+rowInitialVoice,column = numberColumn).value
##            previousNumberQuestion = sheetVoice.cell(row = n+rowInitialVoice-1,column = 1).value
##            numberQuestion = sheetVoice.cell(row = n+rowInitialVoice,column = 1).value
##            if (keeponVoice != "None" and numberQuestion == previousNumberQuestion) or (i == 0 and keeponVoice != "None"):
##                #the second condition is to avoid taking the first element of the next question
##                #the third condition is to take the first element of the first question if keeponVoice != "None"
##                    #(without it, the function will not enter the first time in the condition because
##                    #it will compare '1' to 'Welcome window' which will give false for the second condition)
##                listVoiceQuestion.append(keeponVoice)
##                firstIf = True
##            if (numberQuestion != previousNumberQuestion and type(previousNumberQuestion) != unicode) or i+1 == numberQuiz:
##                #the second condition is to include the first element of the first question in the first list of the global list
##                #the third condition is to take the last list which corresponds to the last question
##                    #(without it, the function will not enter in the condition for the last time because
##                    #it will compare '11' to '11' which will give false for the first condition)
##                listVoice.append(listVoiceQuestion)
##                listVoiceQuestion = [keeponVoice]
##                if keeponVoice == 'None':
##                    listVoiceQuestion = []
##                if i+1 == numberQuiz and firstIf == False:
##                    #if there is not this condition, the last audio file will not be take into account
##                    #indeed, listVoiceQuestion = [keeponVoice] is done after listVoice.append(listVoiceQuestion)
##                    # so the final list is not updated for the last element
##                    # there is not this problem for the first element as for this time, the function enters in the first if
##                    listVoice.append(listVoiceQuestion)
##                firstIf = False
##    return listVoice
