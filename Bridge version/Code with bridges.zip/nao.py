################################ EXAMPLE DOCS #########################
#http://doc.aldebaran.com/2-1/naoqi/core/albehaviormanager.html#albehaviormanager
# -*- encoding: UTF-8 -*- 

import time
import threading

from naoqi import ALProxy

######################## NAO VOICES ######################
def playVoiceNao(window,numberColumn,robotIP,port,*i):
    """ To play the audio files following the window
    Arguments:
    - window = "welcome", "end" or "quiz"
    - numberColumn = 2 (main voices) 3 or 4 (voices for end question)
    - i --> number of the question (useless if window != "quiz")
    """
    aup = ALProxy("ALAudioPlayer", robotIP, PORT)
    voice = robotData(window,numberColumn,False,False,"Nao Voices")# data.py
    if window == "quiz":
        for j in range(len(voice[i[0]])):
            # i is a tuple, we have to transform it in int
            a = '' + voice[i[0]][j]
            aup.playFile(a)
    else:
        for j in range(len(voice)):
            a = '' + voice[j]
            aup.playFile(a)

################################ MOVE NAO ################################
def launchNao(window,numberColumn,endQuestion,robotIP,port,*i):
    """ To launch the movements of a Keepon
    Appeal the two functions
    keeponMove(listeKeepon,window,keepon,*i)
    Arguments:
    - window : for keeponMovement --> "quiz" or other
    - numberColumn : for Right (= 3) or Left (= 2)
    - endQuestion : True --> this is for the end of a question; False --> the contrary
    - robotIP and port: initialisation of the Nao (from the controller.py)
    """
    managerProxy = ALProxy("ALBehaviorManager", robotIP, port)
    if endQuestion == False:
        listeNao = robotData(window,numberColumn,endQuestion,True,"Nao")
    else:
        listeNao = robotData(window,numberColumn,endQuestion,True,"Nao")
    if window == "quiz":# i is a tuple, we have to transform it in int
        a = threading.Thread(None, naoMove, None, (listeKeepon,window,managerProxy,i[0]), {})
    else:
        a = threading.Thread(None, naoMove, None, (listeKeepon,window,managerProxy), {})
    return a

def runBehavior(managerProxy,behaviorName):
    ''' Launch a behavior, if possible.
    Used in naoMove(listeNao,window,managerProxy,*i)
    Arguments:
    - managerProxy: for ALProxy
    - behaviorName: str path of the behavior name
    '''
    # Check that the behavior exists.
    if (managerProxy.isBehaviorInstalled(behaviorName)):
    # Returns true if it is a valid behavior
        # Check that it is not already running.
        if (not managerProxy.isBehaviorRunning(behaviorName)):
            # Launch behavior. This is a blocking call, use post if you do not
            # want to wait for the behavior to finish.
            managerProxy.runBehavior(behaviorName)
            # method post: http://doc.aldebaran.com/2-1/dev/naoqi/index.html#naoqi-proxy
            time.sleep(0.5)
        else:
            print "Behavior is already running."
    else:
        print "Behavior not found."
        return
##    names = managerProxy.getRunningBehaviors()# Return running behaviors
##    print "Running behaviors:"
##    print names

def naoMove(listeNao,window,managerProxy,*i):
    """ Execute the list of instructions of the Keepon,
    contained in the parameter listeKeepon. Used in launchKeepon()
    Arguments:
    - listeNao : list of instructions
    - window: "quiz" or other
    - managerProxy: initialisation of the Nao with proxy (from the controller.py)
    - i: not mandatory following the case
    """
    if window == "quiz":
        for j in range(len(listeNao[i[0]])):# i is a tuple, we have to transform it in int
            ################################ PYTHON 2.7 START #######################
            if type(listeNao[i[0]][j]) == str:
            ################################ PYTHON 2.7 START #######################
                path = "behaviors_master_thesis/" + listeNao[i[0]][j]
                runBehavior(managerProxy,path)
            else:
                time.sleep(listeNao[i[0]][j])
    else:
        for j in range(len(listeNao)):
            ################################ PYTHON 2.7 START #######################
            if type(listeNao[j]) == str:
            ################################ PYTHON 2.7 START #######################
                path = "library/" + listeNao[j]
                runBehavior(managerProxy,path)
            else:
                time.sleep(listeNao[j])

    # Stop the behavior.
##    if (managerProxy.isBehaviorRunning(behaviorName)):
##        managerProxy.stopBehavior(behaviorName)# Stop a behavior
##        time.sleep(1.0)
##    else:
##        print "Behavior is already stopped."
##
##    names = managerProxy.getRunningBehaviors()# Return running behaviors
##    print "Running behaviors:"
##    print names
