from data import *

import time
import threading
import pyglet

######################## KEEPON VOICES ######################
def playVoiceKeepon(window,numberColumn,*i):
    """ To play the audio files following the window
    Arguments:
    - window = "welcome", "end" or "quiz"
    - numberColumn = 2 (main voices) 3 or 4 (voices for end question)
    - i --> number of the question (useless if window != "quiz")
    """
    voice = robotData(window,numberColumn,False,False,"Keepon Voices")# data.py
    player = pyglet.media.Player()
    if window == "quiz":
        for j in range(len(voice[i[0]])):# i is a tuple, we have to transform it in int
            a = 'Voices/' + voice[i[0]][j]
            sound = pyglet.resource.media(a)
            player.queue(sound)
            length = sound.duration# to get length in second of the audio file
    else:
        for j in range(len(voice)):
            a = 'Voices/' + voice[j]
            sound = pyglet.resource.media(a)
            player.queue(sound)
            length = sound.duration
            #useless but if there is not this line --> error because I return the variable at the end of the function
    player.play()
    return length
    

################################ MOVE KEEPON ################################
def launchKeepon(window,numberColumn,endQuestion,keepon,*i):
    """ To launch the movements of a Keepon
    Appeal the two functions
    keeponMove(listeKeepon,window,keepon,*i)
    Arguments:
    - window : for keeponMovement --> "quiz" or other
    - numberColumn : for Right (= 3) or Left (= 2)
    - endQuestion : True --> this is for the end of a question; False --> the contrary
    - sheetName: str
    - keepon: initialisation of the Keepon with serial (from the controller.py)
    """
    if endQuestion == False:
        listeKeepon = robotData(window,numberColumn,endQuestion,True,"Keepon")
    else:
        listeKeepon = robotData(window,numberColumn,endQuestion,True,"Keepon")
    if window == "quiz":# i is a tuple, we have to transform it in int
        a = threading.Thread(None, keeponMove, None, (listeKeepon,window,keepon,i[0]), {})
    else:
        a = threading.Thread(None, keeponMove, None, (listeKeepon,window,keepon), {})
    return a

def initializeKeepon(keepon):
    ################################ PYTHON 2.7 START #######################
    keepon.write("SPEED PAN 255;")
    keepon.write("SPEED TILT 255;")
    time.sleep(0.5)
    keepon.write("MOVE PAN 0;")
    time.sleep(0.5)
    keepon.write("MOVE TILT 0;")
    time.sleep(0.5)
    ################################ PYTHON 2.7 END #######################

def stopKeepon(keepon):
    ################################ PYTHON 2.7 START #######################
    keepon.write("MOVE STOP;")
    ################################ PYTHON 2.7 END #######################

def keeponMove(listeKeepon,window,keepon,*i):
    """ Execute the list of instructions of the Keepon,
    contained in the parameter listeKeepon. Used in launchKeepon()
    Arguments:
    - listeKeepon : list of instructions
    - window: "quiz" or other
    - keepon: initialisation of the Keepon with serial (from the controller.py)
    - i: not mandatory following the case
    """
    if window == "quiz":
        for j in range(len(listeKeepon[i[0]])):# i is a tuple, we have to transform it in int
            ################################ PYTHON 2.7 START #######################
            if type(listeKeepon[i[0]][j]) == str:
            ################################ PYTHON 2.7 START #######################
                keepon.write(listeKeepon[i[0]][j])
            else:
                time.sleep(listeKeepon[i[0]][j])
    else:
        for j in range(len(listeKeepon)):
            ################################ PYTHON 2.7 START #######################
            if type(listeKeepon[j]) == str:
            ################################ PYTHON 2.7 START #######################
                keepon.write(listeKeepon[j])
            else:
                time.sleep(listeKeepon[j])
