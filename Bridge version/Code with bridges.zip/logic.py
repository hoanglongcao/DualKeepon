from Tkinter import *
from PIL import Image, ImageTk

from openpyxl import load_workbook

import pyglet

##################################### KEEPON MOVE - MODULE ##################
import time
import threading

from data import *
from controller import *

excelFile = load_workbook(filename='Datas.xlsx')
sheetData = excelFile['Datas']

def windowAlert():
    window = Tk()
    texts = textOutQuiz()# data.py
    fieldLabel = Label(window, text=texts["alert"])
    fieldLabel.pack()
    button = Button(window,text = texts["buttonQuit"], command = window.destroy)
    button.pack()
    
##################################### REGISTER ###############################
listeData = []
def buttonRegister(window,name,firstName,listeAge,listeGender):
    a = listeAge.curselection()
    b = listeGender.curselection()
    if name == "" or firstName == "" or a == () or b == ():
        windowAlert()
    else:
        age = listeAge.get(a)
        gender = listeGender.get(b)
        listeData.append(name)
        listeData.append(firstName)
        listeData.append(age)
        listeData.append(gender)
        window.destroy()

##################################### QUIZ BUTTONS ###############################
numberChoice = {"manRight":0, "womanLeft" : 0}
i = 0
listeMan = []
listeWoman = []
def numberClickRight(window,frame,buttonR,buttonL,pictureR,pictureL,messages,label,n):
    global i
    ##################################### MOVE ###############################
    stopRobot()# controller.py
    initializeRobot()# controller.py
    launchRobotQuiz(True,i) # end question controller.py
    ##################################### VOICE ###############################
    playVoiceQuiz(4,i)# controller.py
    ##################################### DATA ###############################
    numberChoice["manRight"] = numberChoice["manRight"]+1
    listeMan.append(1)
    listeWoman.append(0)
    i = i + 1
    if i == n:
        ##################################### END QUIZ ###############################
        window.destroy()
        writeExcel()
    else:
        buttonR.config(state=DISABLED)#disabled again the buttons
        buttonL.config(state=DISABLED)
        ##################################### NEXT QUESTION ##########################
        label["text"] = messages[i]
        ################################ PYTHON 2.7 START #######################
        pictureRight = ImageTk.PhotoImage(file = pictureR[i])
        pictureLeft = ImageTk.PhotoImage(file = pictureL[i])
        ################################ PYTHON 2.7 END #######################
        buttonR["image"] = pictureRight#pour remplacer l'image de droite
        buttonL["image"] = pictureLeft#pour remplacer l'image de gauche
        window.update_idletasks()
        window.update()
        length = playVoiceQuiz(2,i)# controller.py
##################################### KEEPON MOVE - START ######################
        launchRobotQuiz(False,i) # controller.py
##################################### KEEPON MOVE - END ######################
        time.sleep(length)# wait length (time of the conversation) seconds before activate the buttons
        buttonR.config(state="normal")
        buttonL.config(state="normal")
    window.mainloop()
    
def numberClickLeft(window,frame,buttonR,buttonL,pictureR,pictureL,messages,label,n):
    global i
    ##################################### MOVE ###############################
    stopRobot()# controller.py
    initializeRobot()# controller.py
    launchRobotQuiz(True,i) # end question controller.py
    ##################################### VOICE ###############################
    playVoiceQuiz(3,i)# controller.py
    ##################################### DATA ###############################
    numberChoice["womanLeft"] = numberChoice["womanLeft"]+1
    listeMan.append(0)
    listeWoman.append(1)
    i = i + 1
    if i == n:
        ##################################### END QUIZ ###############################
        window.destroy()
        writeExcel()
    else:
        buttonR.config(state=DISABLED)# disabled again the buttons
        buttonL.config(state=DISABLED)
        ##################################### NEXT QUESTION ##########################
        label["text"] = messages[i]
        ################################ PYTHON 2.7 START #######################
        pictureRight = ImageTk.PhotoImage(file = pictureR[i])
        pictureLeft = ImageTk.PhotoImage(file = pictureL[i])
        ################################ PYTHON 2.7 END #######################
        buttonR["image"] = pictureRight#pour remplacer l'image de droite
        buttonL["image"] = pictureLeft#pour remplacer l'image de gauche
        window.update_idletasks()
        window.update()
        length = playVoiceQuiz(2,i)# controller.py
        ##################################### KEEPON MOVE ######################
        launchRobotQuiz(False,i)# controller.py
        time.sleep(length)# wait length (time of the conversation) seconds before activate the buttons
        buttonR.config(state="normal")
        buttonL.config(state="normal")
    window.mainloop()

##################################### WRITE EXCEL ###############################
def writeExcel():
    listeNumberChoice = [numberChoice["manRight"],numberChoice["womanLeft"]]
    liste = listeData + listeMan + listeNumberChoice
    sheetData.append(liste)
    excelFile.save("Datas.xlsx")
