# -*- coding: iso-8859-1 -*-

# We import Tkinter
from Tkinter import *
from PIL import Image, ImageTk

from data import *
from logic import *

texts = textOutQuiz()# data.py

############################### POSITION TEXT #################################
def displayText(i,window,dictionaryTexts,x,y):
    """Permit to display a specific text in the window"""
    message = dictionaryTexts[i]
    fieldLabel = Label(window, text=message)
    fieldLabel.grid(row = x, column = y)

############################## WELCOME #########################################
def welcome():
    """Create the welcome Window"""
    window = Tk()
    #window.title('Keepon Quiz')
    #window.iconbitmap("icone.ico")
    ############################# TEXT #########################################
    displayText("welcomeText",window,texts,0,1)
    ############################# PICTURE ######################################
    keeponRight = resizePicture(texts["PictureRight"],300)# data.py
    keeponLeft = resizePicture(texts["PictureLeft"],300)# data.py
    photoRight = ImageTk.PhotoImage(file = keeponRight)# load picture
    photoLeft = ImageTk.PhotoImage(file = keeponLeft)
    labelRight = Label(image = photoRight)# put picture in label
    labelLeft = Label(image = photoLeft)
    labelRight.grid(row = 0, column = 2)# place label
    labelLeft.grid(row = 0, column = 0)
    #################################### BUTTON ###############################
    button = Button(window,text = texts["buttonNext"], command = window.destroy)
    button.grid(row = 2, column = 1)
    #################################### ???? ###############################
    window.update_idletasks()
    window.update()
    ################################# CONTROLLER #############################
    playVoiceWelcome()# controller.py
    launchRobotWelcome()# controller.py
    window.mainloop()

############################## REGISTER #######################################
def register():
    """Creates the register window"""
    window = Tk()
    #window.title('Keepon Quiz')
##    framework = Frame(window, width=500, height=500, borderwidth=1)#gros probl�me!!!!
##    framework.pack()
    ###################################### TEXT ##############################
    displayText("Introduction",window,texts,0,0)
    displayText("Forms",window,texts,1,0)
    displayText("Name",window,texts,2,0)
    displayText("firstName",window,texts,3,0)
    displayText("Age",window,texts,4,0)
    displayText("Gender",window,texts,5,0)
    #displayText("Information4",window,texts,5,0)
    ################################# INPUT NAME ##############################
    nameEntry = StringVar()
    line_name = Entry(window, textvariable = nameEntry, width=30)
    line_name.grid(row = 2, column = 1)
    firstNameEntry = StringVar()
    line_first = Entry(window, textvariable = firstNameEntry, width=30)
    line_first.grid(row = 3, column = 1)
    ############################# LISTBOX AGE ##############################
    exportselection=0
    frameAge = Frame(window)
    frameAge.grid(row = 4, column = 1)
    listeAge = Listbox(frameAge,height=2,exportselection=0)
    #exportselection=0 is for being able to select each listbox (and not only one selection for the whole window)
    sbar = Scrollbar(frameAge)
    sbar.config(command=listeAge.yview)
    listeAge.config(yscrollcommand=sbar.set)
    sbar.pack(side=RIGHT, fill=Y)
    listeAge.pack(side=LEFT, expand=YES, fill=BOTH)
    age = 19
    while age < 75:
        age = age + 1
        listeAge.insert(END, age)
    ############################### GENDER ##############################
    listeGender = Listbox(window,height=2,exportselection=0)
    listeGender.grid(row = 5, column = 1)
    listeGender.insert(0,texts["male"])
    listeGender.insert(1,texts["female"])
    buttonBegin = Button(window, text=texts["buttonNext"],command = lambda : \
                         buttonRegister(window,nameEntry.get(),firstNameEntry.get(),\
                                        listeAge,listeGender))
    buttonBegin.grid(row = 6, column = 0)
    window.mainloop()

###################################### RULES ##############################
def rules():
    """Creates the rules window"""
    window = Tk()
    #window.title('Keepon Quiz')
    ###################################### TEXT ##############################
    displayText("Rules",window,texts,0,0)
    ###################################### BUTTON ##############################
    buttonBegin = Button(window, text=texts["buttonNext"], command = window.destroy)
    buttonBegin.grid(row = 2, column = 0)
    ###################################### IMAGE ##############################
    picture = resizePicture(texts["PictureRules"],600)
    photo = ImageTk.PhotoImage(file = picture)
    label = Label(image = photo)
    label.grid(row = 1,column = 0)
    window.mainloop()

###################################### END ##############################
def end():
    """Creates the end window"""
    window = Tk()
    #window.title('Keepon Quiz')
##    framework = Frame(window, width=500, height=500, borderwidth=1)#gros probl�me!!!!
##    framework.pack()
    ###################################### TEXT ##############################
    displayText("End",window,texts,0,0)
    ###################################### PICTURE ##############################
    picture = resizePicture(texts["PictureEnd"],300)
    photo = ImageTk.PhotoImage(file = picture)
    label = Label(image = photo)
    label.grid(row = 1,column = 0)
    ###################################### BUTTON ##############################
    buttonBegin = Button(window, text=texts["buttonQuit"], command = window.destroy)
    buttonBegin.grid(row = 2, column = 0)
    window.update_idletasks()
    window.update()
    ################################ CONTROLLER ##########################
    playVoiceEnd()# controller.py
    initializeRobot()# controller.py
    launchRobotEnd()# controller.py
    window.mainloop()

##################################### QUIZ ################################

def quiz(window,picturesRight,picturesLeft):
    ################################### TEXT ###############################
    messages = textQuiz()
    n = len(messages)
    fieldLabel = Label(window, height=3, text=messages[i])
    fieldLabel.pack(side = "top")
    ############################ FRAMEWORK ###############################
    framework = Frame(window)
    framework.pack()
    ############################## BUTTONS ###############################
    photoRight = ImageTk.PhotoImage(file = picturesRight[i])
    photoLeft = ImageTk.PhotoImage(file = picturesLeft[i])
    buttonRight = Button(framework, state = DISABLED, width =500, height =500, image=photoRight, \
                         command = lambda : numberClickRight\
                         (window,framework,buttonRight,buttonLeft,picturesRight,\
                          picturesLeft,messages,fieldLabel,n))#the buttons are disabled!
    buttonLeft = Button(framework, state = DISABLED, width =500, height =500, image=photoLeft, \
                        command = lambda : numberClickLeft\
                        (window,framework,buttonRight,buttonLeft,picturesRight,\
                         picturesLeft,messages,fieldLabel,n))
    buttonLeft.grid(row = 0, column = 0)
    buttonRight.grid(row = 0, column = 1)
    window.update_idletasks()
    window.update()
    ##################################### CONTROLLER ######################
    initializeRobot()# controller.py
    length = playVoiceQuiz(2,0)# controller.py
    launchRobotQuiz(False,0)# controller.py
    time.sleep(length)# wait length (time of the conversation) seconds before activate the buttons
    buttonRight.config(state="normal")
    buttonLeft.config(state="normal")
    window.mainloop()

def main():
    initializeRobot()# controller.py
    welcome()
    register()
    rules()
##    text = textQuiz()# data.py
    picturesRight = pictures("ImagesMan",4)# data.py
    picturesLeft = pictures("ImagesWoman",3)# data.py
##    n = len(text)#to have n questions
    window = Tk()
    #window.title('Keepon Quiz')
##    quiz(window,picturesRight,picturesLeft,n)
    quiz(window,picturesRight,picturesLeft)
    end()

main()

####################################### INUTILE #############################
##    print (numberChoice)
##    print (listeMan)
##    print(listeWoman)

# C'�tait l� avant MA2
##def problem():
##    window = Tk()
##    fieldLabel = Label(window, height=3, text="Warning! There is a problem in the program! \n\
##Contact immediately the organiser!")
##    fieldLabel.pack(side = "top")
##    buttonRight = Button(window, text="Quit", command = window.destroy)

#can1.grid(row =1, column =3, rowspan =3, padx =10, pady =5)
#http://www.fevrierdorian.com/blog/post/2009/03/16/Tkinter%3A-Faire-communiquer-les-variables-de-l-interface.
#http://python.developpez.com/cours/TutoSwinnen/?page=Chapitre8#L8.5
#https://fr.wikibooks.org/wiki/Programmation_Python/Tkinter#Principes_de_base
#http://tkinter.fdex.eu/doc/labw.html
