from openpyxl import load_workbook
from Tkinter import *
import serial

excelFile = load_workbook(filename='Datas.xlsx')

sheetGeneral = excelFile['General']

doubleKeepon = sheetGeneral['B29'].value
doubleNao = sheetGeneral['B30'].value
KeeponL_NaoR = sheetGeneral['B31'].value
KeeponR_NaoL = sheetGeneral['B32'].value

def windowAlertControl():
    window = Tk()
    window.title('Alert')
    fieldLabel = Label(window, text="You haven't correctly selected the system. Please, make sure that you have right \"yes\" only one time at the right place.")
    fieldLabel.grid(row = 0, column = 0)
    button = Button(window,text = 'OK', command = window.destroy)
    button.grid(row = 1, column = 0)
    window.mainloop()
    
######################## INITIALIZATION ######################
if doubleKeepon == "yes" and doubleNao != "yes" and KeeponL_NaoR != "yes" and KeeponR_NaoL != "yes":
    from keepon import *
    sheetKeepon = excelFile['Keepon']
    keeponRight = serial.Serial(sheetKeepon['C2'].value,9600)
    time.sleep(1)
    ##keeponLeft = serial.Serial(sheetKeepon['B2'].value,9600)
    ##time.sleep(1)
    robots = "keepon"
elif doubleNao == "yes" and doubleKeepon != "yes" and KeeponL_NaoR != "yes" and KeeponR_NaoL != "yes":
    from nao import *
    sheetNao = excelFile['Nao']
    robotIPRight = sheetNao['C3']
    portRight = sheetNao['C2']
    robotIPLeft = sheetNao['B3']
    portLeft = sheetNao['B2']
    robots = "nao"
elif KeeponL_NaoR == "yes" and doubleKeepon != "yes" and doubleNao != "yes" and KeeponR_NaoL != "yes":
    from keepon import *
    from nao import *
    sheetKeepon = excelFile['Keepon']
    sheetNao = excelFile['Nao']
    keeponLeft = serial.Serial(sheetKeepon['B2'].value,9600)
    time.sleep(1)
    robotIPRight = sheetNao['C3']
    portRight = sheetNao['C2']
    robots = "KeeponLNaoR"
elif KeeponR_NaoL == "yes" and doubleKeepon != "yes" and doubleNao != "yes" and KeeponL_NaoR != "yes":
    from keepon import *
    from nao import *
    sheetKeepon = excelFile['Keepon']
    sheetNao = excelFile['Nao']
    keeponRight = serial.Serial(sheetKeepon['C2'].value,9600)
    time.sleep(1)
    robotIPLeft = sheetNao['B3']
    portLeft = sheetNao['B2']
    robots = "KeeponRNaoL"
else:
    from keepon import *
    robots = "nothing"
    #windowAlertControl()
    
def initializeRobot():
    if robots == "keepon":
        initializeKeepon(keeponRight)
##        initializeKeepon(keeponLeft)
    else:
        return

def stopRobot():
    if robots == "keepon":
        stopKeepon(keeponRight)
##        stopKeepon(keeponLeft)
    else:
        return
        
def playVoiceWelcome():
    if robots == "keepon":
        playVoiceKeepon("welcome",2)# keepon.py
##    elif robots == "nao":
##
##    else:
##        return

def launchRobotWelcome():
    if robots == "keepon":
        a = launchKeepon("welcome",3,False,keeponRight)
##        b = launchKeepon("welcome",2,False,keeponLeft)
        a.start()
##        b.start()
    elif robots == "nao":
        a = launchNao("welcome",3,False,robotIPRight,portRight)
        b = launchNao("welcome",2,False,robotIPLeft,portLeft)
        a.start()
        b.start()
    elif robots == "KeeponLNaoR":
        a = launchNao("welcome",3,False,robotIPRight,portRight)
        b = launchKeepon("welcome",2,False,keeponLeft)
        a.start()
        b.start()
    elif robots == "KeeponRNaoL":
        a = launchKeepon("welcome",3,False,keeponRight)
        b = launchNao("welcome",2,False,robotIPLeft,portLeft)
        a.start()
        b.start()
    else:
        return
    
def playVoiceEnd():
    if robots == "keepon":
        playVoiceKeepon("end",2)# keepon.py
##    elif robots == "nao":
##        
##    else:
##        return

def launchRobotEnd():
    if robots == "keepon":
        a = launchKeepon("end",3,False,keeponRight)
##        b = launchKeepon("end",2,False,keeponLeft)
        a.start()
##        b.start()
    elif robots == "nao":
        a = launchNao("end",3,False,robotIPRight,portRight)
        b = launchNao("end",2,False,robotIPLeft,portLeft)
        a.start()
        b.start()
    elif robots == "KeeponLNaoR":
        a = launchNao("end",3,False,robotIPRight,portRight)
        b = launchKeepon("end",2,False,keeponLeft)
        a.start()
        b.start()
    elif robots == "KeeponRNaoL":
        a = launchKeepon("end",3,False,keeponRight)
        b = launchNao("end",2,False,robotIPLeft,portLeft)
        a.start()
        b.start()
    else:
        return

def playVoiceQuiz(numberColumn,i):
    if robots == "keepon" or robots == "nothing":
        return playVoiceKeepon("quiz",numberColumn,i)# keepon.py
        # we do return because we need the length of the audio file
##    elif robots == "nao":
##        
##    else:
##        return

def launchRobotQuiz(endQuestion,i):
    if robots == "keepon":
        a = launchKeepon("quiz",3,endQuestion,keeponRight,i)
##        b = launchKeepon("quiz",2,endQuestion,keeponLeft,i)
        a.start()
##        b.start()
    elif robots == "nao":
        a = launchNao("quiz",3,endQuestion,robotIPRight,portRight,i)
        b = launchNao("quiz",2,endQuestion,robotIPLeft,portLeft,i)
        a.start()
        b.start()
    elif robots == "KeeponLNaoR":
        a = launchNao("quiz",3,endQuestion,robotIPRight,portRight,i)
        b = launchKeepon("quiz",2,endQuestion,keeponLeft,i)
        a.start()
        b.start()
    elif robots == "KeeponRNaoL":
        a = launchKeepon("quiz",3,endQuestion,keeponRight,i)
        b = launchNao("quiz",2,endQuestion,robotIPLeft,portLeft,i)
        a.start()
        b.start()
    else:
        return
